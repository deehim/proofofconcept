//
//  ListVC.m
//  ProofOfConcept
//
//  Created by SYS-27 on 11/02/18.
//  Copyright © 2018 SYS-27. All rights reserved.
//

#import "ListVC.h"
#import "DetailsVC.h"
#import <UIImageView+WebCache.h>

@interface ListVC (){
    NSMutableArray *responseArray;
    UIRefreshControl *refreshControler;
}
@end

@implementation ListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //NSMutableArray Allocation //
    responseArray=[[NSMutableArray alloc] init];
    //UIRefreshControl Allocation //
    refreshControler = [[UIRefreshControl alloc] init];
     _activityIndicator.hidden=NO;
    [_activityIndicator startAnimating];
    if (@available(iOS 10.0, *)) {
        _listTableview.refreshControl = refreshControler;
    } else {
    // Fallback on earlier versions
    }
   [refreshControler addTarget:self action:@selector(pullToRefresh:) forControlEvents:UIControlEventValueChanged];
    _listTableview.rowHeight = UITableViewAutomaticDimension;
    _listTableview.estimatedRowHeight = 68;
    [self getListService];
}
#pragma UIRefreshControl Action
- (IBAction)pullToRefresh:(id)sender {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        // (...code to get new data here...)
        dispatch_async(dispatch_get_main_queue(), ^{
            //any UI refresh
            [self getListService];
            [refreshControler beginRefreshing];
        });
    });
}
#pragma Service Call Method
-(void)getListService{
    NSCharacterSet *expectedCharSet = [NSCharacterSet URLQueryAllowedCharacterSet];
    NSString *urlString = [@"https://dl.dropboxusercontent.com/s/2iodh4vg0eortkl/facts.json" stringByAddingPercentEncodingWithAllowedCharacters:expectedCharSet];
    NSURLSession *session = [NSURLSession sharedSession];
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLSessionDataTask *dataTask = [session dataTaskWithURL:url completionHandler:^(NSData* data, NSURLResponse* response, NSError *error){
        if(data != nil){
            NSString *latinString = [[NSString alloc] initWithData:data encoding:NSISOLatin1StringEncoding];
            NSData *jsonData = [latinString dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableLeaves error:&error];
            NSLog(@"response = %@",json);
            dispatch_async(dispatch_get_main_queue(), ^(void){
                _activityIndicator.hidden=YES;
               [_activityIndicator stopAnimating];
               [refreshControler endRefreshing];
               self.navigationItem.title = [json valueForKey:@"title"];
               responseArray=[json valueForKey:@"rows"];
                [_listTableview reloadData];
            });
        }
    }];
    [dataTask resume];
}
#pragma UITableviewDatasorce Protocol
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;  //count of section
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [responseArray count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSString *titleStr=[[responseArray objectAtIndex:indexPath.row] valueForKey:@"title"];
    NSString *descriptionStr=[[responseArray objectAtIndex:indexPath.row] valueForKey:@"description"];
    NSString *imgStr=[[responseArray objectAtIndex:indexPath.row]valueForKey:@"imageHref"];
    
    ListCell *cell = (ListCell *)[tableView dequeueReusableCellWithIdentifier:@"ListCellIdentifier" forIndexPath:indexPath];
    if (cell == nil) {
        cell = [[ListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ListCellIdentifier"];
    }
    
    if (![titleStr isKindOfClass:[NSNull class]]) {
        if ([titleStr length] > 0) {
            cell.titleLabel.text = [[responseArray objectAtIndex:indexPath.row] valueForKey:@"title"];
        }
    }else{
        cell.titleLabel.text = @"No title available right now";
    }
    
    if (![descriptionStr isKindOfClass:[NSNull class]]) {
        if ([descriptionStr length] > 0) {
          cell.descriptionLabel.text=[[responseArray objectAtIndex:indexPath.row] valueForKey:@"description"];
        }
    }else{
        cell.descriptionLabel.text = @"No description available right now";
    }
    
    if (![imgStr isKindOfClass:[NSNull class]]) {
        if ([imgStr length] > 0) {
            cell.imageHref.hidden = NO;
            cell.imagewidth.constant=50;
            cell.imageRightMargin.constant=15;
            [cell.imageHref sd_setImageWithURL:[NSURL URLWithString:imgStr] placeholderImage:[UIImage imageNamed:@"noimage"]];
        }
    }else{
        cell.imageHref.image = nil;
        cell.imageHref.hidden = YES;
        cell.imagewidth.constant=0;
        cell.imageRightMargin.constant=0;
    }
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *imgStr=[[responseArray objectAtIndex:indexPath.row]valueForKey:@"imageHref"];
    NSString *titleStr=[[responseArray objectAtIndex:indexPath.row] valueForKey:@"title"];
    NSString *descriptionStr=[[responseArray objectAtIndex:indexPath.row] valueForKey:@"description"];
   // Initiation Viewcontroller Identifier //
    UIStoryboard *storyboard=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    DetailsVC *VC=[storyboard instantiateViewControllerWithIdentifier:@"DetailsVCIdentifier"];
    VC.imagestring=imgStr;
    VC.titletring=titleStr;
    VC.descriptiontring=descriptionStr;
    [self.navigationController pushViewController:VC animated:TRUE];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
