//
//  DetailsVC.m
//  ProofOfConcept
//
//  Created by SYS-27 on 12/02/18.
//  Copyright © 2018 SYS-27. All rights reserved.
//

#import "DetailsVC.h"
#import <UIImageView+WebCache.h>

@interface DetailsVC ()

@end

@implementation DetailsVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
     //UINvaigation Setup //
     self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    if (![self.titletring isKindOfClass:[NSNull class]]) {
        if ([self.titletring length] > 0) {
            self.titleLabel.text = self.titletring;
        }
    }else{
        self.titleLabel.text = @"No title available right now";
    }
    if (![self.descriptiontring isKindOfClass:[NSNull class]]) {
        if ([self.descriptiontring length] > 0) {
            self.descriptionLabel.text=self.descriptiontring;
        }
    }else{
        self.descriptionLabel.text = @"No description available right now";
    }
    // Displaying Detail Image.
    if (![self.imagestring isKindOfClass:[NSNull class]]) {
        if ([self.imagestring length] > 0) {
            [self.imageHref sd_setImageWithURL:[NSURL URLWithString:self.imagestring] placeholderImage:[UIImage imageNamed: @"noimage"]];
        }
    }else{
         [self.imageHref sd_setImageWithURL:[NSURL URLWithString:@""] placeholderImage:[UIImage imageNamed:@"noimage"]];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
