//
//  DetailsVC.h
//  ProofOfConcept
//
//  Created by SYS-27 on 12/02/18.
//  Copyright © 2018 SYS-27. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailsVC : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *imageHref;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *descriptionLabel;
@property NSString *imagestring;
@property NSString *titletring;
@property NSString *descriptiontring;

@end
